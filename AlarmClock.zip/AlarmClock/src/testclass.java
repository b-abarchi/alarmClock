
public class testclass {
	public static class D

	{

	public static void main(String[] args)

	{

	TikTok a1= new TikTok();

	TikTok a2= new TikTok(22,30,4);

	TikTok a3= new TikTok(24,57,9);

	System.out.println("Object 1:"+a1);

	System.out.println("Object 2:"+a2);

	System.out.println("Object 3:"+a3);

	a3.snooze();

	}

	}
}